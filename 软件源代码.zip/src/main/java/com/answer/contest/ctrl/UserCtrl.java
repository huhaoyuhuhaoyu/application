package com.answer.contest.ctrl;

import com.answer.contest.dto.UserDTO;
import com.answer.contest.entity.*;
import com.answer.contest.mapper.RecordMapper;
import com.answer.contest.mapper.WaitMapper;
import com.answer.contest.serv.UserServ;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.relational.core.sql.In;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;


@RestController
@RequestMapping("user")
public class UserCtrl {

    @Autowired
    private UserServ userServ;
    @Autowired
    WaitMapper waitMapper;
    @Autowired
    private RecordMapper recordMapper;

    @PostMapping("login")
    public Result login(@RequestBody UserDTO userDTO){
        return userServ.login(userDTO);
    }

    @PostMapping("reg")
    public Result reg(@RequestBody UserDTO userDTO){
        Result rs = userServ.reg(userDTO);
        User user = userServ.getOne(userDTO.getAccount());
        Record record = new Record();
        record.setUserId(user.getId());
        record.setUserName(user.getUserName());
        recordMapper.insertSelective(record);
        return rs;
    }

    @GetMapping("addUser")
    public void addUser(){
        userServ.addUser();
    }

    @GetMapping("addRecord")
    public void addRecord(){
        userServ.addRecord();
    }

    @GetMapping("/wait")
    public Result wait(Integer id){
        Wait query = waitMapper.selectByPrimaryKey(id);
        List<Wait> total = waitMapper.selectAll();
        if(query != null){
            if(total.size() == 2){
                return new Result().genFailResult(ResultCode.PART_FAIL, "比赛已开始");
            }
            return new Result().genFailResult(ResultCode.NOT_DATA_AUTHORIZED, "您已在竞赛中...");
        }

        if(total.size() > 1){
            return new Result().genFailResult(ResultCode.UPPER_LIMIT, "当前房间人数已满，请稍后重试");
        }
        Wait entity = new Wait();
        entity.setUserId(id);
        entity.setCreateTime(new Date());
        waitMapper.insert(entity);
        return new Result().genSuccessResult("加入成功，正在匹配对手...");
    }

    @GetMapping("/isStart")
    public boolean isStart(Integer id){
        List<Wait> query = waitMapper.selectAll();
        return query.size() == 2;
    }

    @GetMapping("/list")
    public List<User> list(Integer id){
        return userServ.list().stream().filter(i -> i.getId() != id).collect(Collectors.toList());
    }
}
