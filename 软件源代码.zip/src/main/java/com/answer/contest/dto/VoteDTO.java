package com.answer.contest.dto;

import lombok.Data;

/**
 * @author dzy
 * @date 2020/6/28
 * @desc
 */
@Data
public class VoteDTO {

    private Integer userId;

    private String userName;

    private Integer groupId;

    private String groupName;

}
