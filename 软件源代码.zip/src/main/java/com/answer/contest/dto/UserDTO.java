package com.answer.contest.dto;

import lombok.Data;

/**
 * @author dzy
 * @date 2020/6/28
 * @desc
 */
@Data
public class UserDTO {

    private String account;

    private String password;

    private String username;
}
