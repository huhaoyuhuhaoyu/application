package com.answer.contest.serv;

import com.answer.contest.dto.UserDTO;
import com.answer.contest.entity.Result;
import com.answer.contest.entity.User;

import java.util.List;

public interface UserServ {

    Result login (UserDTO userDTO);

    Result reg (UserDTO userDTO);

    void addUser ();

    void addRecord ();

    User getOne(String id);

    List<User> list();
}
