package com.answer.contest.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Id;
import java.util.Date;

@Data
public class Wait {
    @Id
    private Integer userId;

    @Column(name = "create_time")
    private Date createTime;

}