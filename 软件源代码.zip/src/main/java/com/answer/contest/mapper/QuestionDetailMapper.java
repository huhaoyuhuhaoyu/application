package com.answer.contest.mapper;

import com.answer.contest.entity.QuestionDetail;
import tk.mybatis.mapper.common.Mapper;

public interface QuestionDetailMapper extends Mapper<QuestionDetail> {
}