package com.answer.contest.mapper;


import com.answer.contest.entity.Wait;
import org.apache.ibatis.annotations.Delete;
import tk.mybatis.mapper.common.Mapper;

public interface WaitMapper extends Mapper<Wait> {

    @Delete(value = {"DELETE FROM wait"})
    int deleteAll();
}