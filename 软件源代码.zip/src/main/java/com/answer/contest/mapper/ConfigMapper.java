package com.answer.contest.mapper;


import com.answer.contest.entity.Config;
import tk.mybatis.mapper.common.Mapper;

public interface ConfigMapper extends Mapper<Config> {
}