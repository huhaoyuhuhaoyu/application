package com.answer.contest.mapper;

import com.answer.contest.entity.Question;
import tk.mybatis.mapper.common.Mapper;

public interface QuestionMapper extends Mapper<Question> {
}