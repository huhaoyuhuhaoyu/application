package com.answer.contest.mapper;


import com.answer.contest.entity.GGroup;
import tk.mybatis.mapper.common.Mapper;

public interface GroupMapper extends Mapper<GGroup> {
}