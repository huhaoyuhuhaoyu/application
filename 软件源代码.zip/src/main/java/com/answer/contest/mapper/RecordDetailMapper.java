package com.answer.contest.mapper;

import com.answer.contest.entity.RecordDetail;
import tk.mybatis.mapper.common.Mapper;

public interface RecordDetailMapper extends Mapper<RecordDetail> {
}