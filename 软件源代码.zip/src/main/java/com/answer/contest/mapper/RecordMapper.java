package com.answer.contest.mapper;


import com.answer.contest.entity.Record;
import org.apache.ibatis.annotations.Select;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

public interface RecordMapper extends Mapper<Record> {

    List<Record> getRecordList ();

    @Select({"SELECT r.* FROM record r JOIN wait w ON w.user_id = r.user_id ORDER BY r.total_score DESC"})
    List<Record> getRecordByWait();
}